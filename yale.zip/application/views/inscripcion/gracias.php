<section>
    <div class = "container-fluid inscripcion-box">
        <center>
            <h3>¡Muchas gracias por preferirnos!</h3>
            <img src = "<?=base_url()?>assets/img/logo_yale.png" style = "width: 300px;"><br>
            <b>La universidad de Yale te da la bienvenida.</b>
            <hr/>
            <div class = "texto-gracias">
                <p>Hemos recibido tu información para inscribirte a nuestra facultad de arte, nos da gusto avisarte que ya se encuentra en revisión y en unos momentos estarás recibiendo un correo electrónico con tus datos estudiantiles, que son:</p>
                <ol>
                    <li>Matrícula estudiantil</li>
                    <li>Contraseña</li>
                </ol>
                <p>En el momento que tengas estos datos, podrás ingresar al portal de alumnos, inscribirte en eventos y al foro estudiantil.</p>
            </div>
        </center>
    </div>
</section>