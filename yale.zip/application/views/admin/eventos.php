<form method = "POST">
    <input name = "nombre" type = "text" placeholder = "Titulo" /><br>
    <textarea name = "descripcion" type = "text" placeholder = "descripcion"></textarea><br>
    <input name = "fecha_evento" type = "datetime-local" ><br/>
    <input type = "submit">
</form>