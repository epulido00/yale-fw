<div>
	<form>
		<input type="email" name="email" /><br/>
		<input type="password" name="password" /><br/>
		<input type="submit" value="Ingresar"><br/>
	</form>
</div>
